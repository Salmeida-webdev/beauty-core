import { Module } from '@nestjs/common';

import { PrismaModule } from '../../database/prisma/prisma.module';

import { UsuariosController } from './usuarios.controller';
import { UsuariosService } from './usuarios.service';

import { AuditoriaModule } from '../auditoria/auditoria.module';

@Module({
  imports: [
    PrismaModule,
    AuditoriaModule,
  ],

  controllers: [UsuariosController],

  providers: [UsuariosService],

  exports: [UsuariosService],
})
export class UsuariosModule {}