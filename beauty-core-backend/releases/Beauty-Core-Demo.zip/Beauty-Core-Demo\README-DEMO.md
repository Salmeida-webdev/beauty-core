﻿# Beauty Core 1.0 - Demo Package Final

Pacote demo final para apresentacao tecnica/comercial.

Release SHA256: 9B83FD3D50872F2EFD870E97FB5EDA1805495DCAF252154FBDA6B6B7E9321457
Internal SHA256: 9D51EE694F042868146DB32ACC003F40C1471417198387481776B542E6F912B2

Nao contem .env real, codigo-fonte completo, node_modules, dist, coverage, logs, backups ou uploads privados.
